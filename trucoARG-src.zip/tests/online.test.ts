import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { io } from 'socket.io-client';
import type { Socket } from 'socket.io-client';
import type { View, Player } from '../shared/game.ts';
type Room = {
  code: string;
  players: Player[];
  game: View | null;
  chat: { name: string; text: string }[];
};
type Reply = { ok: boolean; error?: string; code?: string; token?: string };
const command = (s: Socket, data: Record<string, unknown>) =>
  new Promise<Reply>((resolve, reject) =>
    s
      .timeout(3000)
      .emit('command', data, (error: Error | null, result: Reply) =>
        error ? reject(error) : resolve(result),
      ),
  );
const connect = (s: Socket) =>
  new Promise<void>((resolve, reject) => {
    s.once('connect', () => resolve());
    s.once('connect_error', reject);
    s.connect();
  });
test('salas reales: 1v1, 2v2, 3v3, manos privadas, turnos y reconexión', async () => {
  const server = spawn(process.execPath, ['server/index.ts'], {
    env: { ...process.env, PORT: '3099' },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  const clients: Socket[] = [];
  try {
    await Promise.race([
      once(server.stdout!, 'data'),
      new Promise((_, reject) =>
        setTimeout(() => reject(Error('Servidor no arrancó')), 7000).unref(),
      ),
    ]);
    for (const size of [2, 4, 6]) {
      const seats: Socket[] = [];
      const states = new Map<string, Room>();
      const listings = new Map<string, { code: string; count: number }[]>();
      for (let i = 0; i < size; i++) {
        const s = io('http://127.0.0.1:3099', { autoConnect: false, reconnection: false });
        s.on('room', (r: Room) => states.set(s.id!, r));
        s.on('tables', (tables: { code: string; count: number }[]) => listings.set(s.id!, tables));
        await connect(s);
        clients.push(s);
        seats.push(s);
      }
      const created = await command(seats[0], {
        action: 'create',
        size,
        target: 15,
        name: 'Mano',
        public: size === 4,
      });
      assert.ok(created.ok);
      await command(seats[0], { action: 'chat', text: 'Mesa creada' });
      assert.equal(
        listings.get(seats[0].id!)!.some((t) => t.code === created.code),
        size === 4,
      );
      if (size === 4)
        assert.equal(listings.get(seats[0].id!)!.find((t) => t.code === created.code)!.count, 1);
      let token = '';
      for (let i = 1; i < size; i++) {
        const joined = await command(seats[i], {
          action: 'join',
          code: created.code,
          name: `Jugador ${i}`,
        });
        assert.ok(joined.ok);
        if (i === 1) token = joined.token!;
      }
      assert.ok((await command(seats[0], { action: 'start' })).ok);
      // Round-trip barrier: state packets are sent before the acknowledgments.
      for (const s of seats) await command(s, { action: 'chat', text: '¡Buenas!' });
      assert.equal(
        listings.get(seats[0].id!)!.some((t) => t.code === created.code),
        false,
      );
      const hands = seats.map((s) => states.get(s.id!)!.game!.hand);
      assert.equal(new Set(hands.flat().map((c) => c.id)).size, size * 3);
      for (const s of seats) {
        const game = states.get(s.id!)!.game!;
        assert.equal('hands' in game, false);
        assert.equal('original' in game, false);
        assert.equal(game.hand.length, 3);
      }
      assert.equal((await command(seats[1], { action: 'play', card: hands[1][0].id })).ok, false);
      assert.equal((await command(seats[0], { action: 'play', card: hands[1][0].id })).ok, false);
      assert.ok((await command(seats[0], { action: 'play', card: hands[0][0].id })).ok);
      const oldId = seats[1].id!;
      seats[1].disconnect();
      const recovered = io('http://127.0.0.1:3099', { autoConnect: false, reconnection: false });
      recovered.on('room', (r: Room) => states.set(recovered.id!, r));
      await connect(recovered);
      clients.push(recovered);
      assert.ok((await command(recovered, { action: 'resume', code: created.code, token })).ok);
      assert.equal(
        states.get(recovered.id!)!.game!.players.some((p) => p.id === oldId),
        false,
      );
      assert.deepEqual(states.get(recovered.id!)!.game!.hand, hands[1]);
      assert.ok((await command(recovered, { action: 'play', card: hands[1][0].id })).ok);
      for (const s of seats) s.disconnect();
      recovered.disconnect();
    }
  } finally {
    clients.forEach((s) => s.disconnect());
    server.kill();
  }
});
