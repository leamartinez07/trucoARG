# Truco argentino

Truco online para 2, 4 o 6 jugadores. La aplicación abre en la sala de mesas: entrar a una pública, crear una privada, compartir un código o jugar contra bots. Baraja española clásica de 40 cartas.

## Ejecutar

Requiere Node.js 24 y pnpm. Con npm también se pueden ejecutar los scripts.

```sh
pnpm install
pnpm dev
```

Abrir http://localhost:5173. Vite redirige Socket.IO al servidor en el puerto 3001. Para probar entre dispositivos en la misma red, abrir la dirección IP del equipo en el puerto 5173 y permitir ambos procesos en el firewall si corresponde.

```sh
pnpm test
pnpm build
pnpm start
```

En producción el servidor sirve `dist` y Socket.IO desde el mismo origen. `PORT` cambia el puerto (3001 por defecto). Requiere un host Node con WebSockets y HTTPS para compartir la partida por internet. No está desplegado automáticamente.

## Incluido

- Salas privadas por código y link, mesas públicas con lista en vivo, nombres, equipos alternados 1v1 / 2v2 / 3v3 y chat.
- Partidas a 15 o 30, jerarquía argentina, bazas y pardas, envido / real / falta, truco / retruco / vale cuatro, al mazo y rotación de mano.
- Envido puede interrumpir el primer truco; empates de tanto se resuelven por mano.
- Práctica local y bots para completar salas. Los bots son básicos: no pretenden simular un jugador experto.
- Servidor autoritativo con barajado criptográfico. Cada cliente recibe únicamente su mano, sus tantos y el estado público.
- Reconexión por token de sesión, pausa ante desconexiones y límite de mensajes por conexión.
- Interfaz adaptable, botones accesibles, diálogos nativos, sonidos opcionales y movimiento reducido.
- Voz, video y señas a través de Discord. **No hay cámara ni micrófono integrados en la página.**

## Reglas acordadas

Sin flor y sin pica-pica (3v3 se juega siempre en equipos). En malas, la falta envido vale lo que le falta al equipo de menor puntaje para llegar al objetivo; en buenas, lo que le falta al de mayor puntaje. El equipo decide el canto: cualquiera de sus integrantes puede responder. Al mazo concede el valor actual del truco. Estas variantes están explicadas en la ayuda.

## Límites actuales

Las salas viven en memoria: reiniciar el servidor las elimina. El código compartido funciona como acceso a la mesa privada, sin cuentas. Un único proceso admite las salas; antes de un lanzamiento público se necesitan persistencia, protección ante abuso a nivel de IP, observabilidad y una política para abandonar o sustituir jugadores desconectados. No hay historial de partidas ni emparejamiento automático; las mesas públicas se eligen de la lista.

## Estructura

- `shared/game.ts`: reglas puras, motor y proyección privada por jugador.
- `server/index.ts`: salas, validación, chat, reconexión y bots.
- `src/main.tsx`: lobby, mesa y controles React.
- `src/Lobby.tsx`: mesas públicas, configuración y entrada por código.
- `src/style.css`: identidad visual y adaptación móvil.
- `tests/`: pruebas del motor y del protocolo multijugador.

## Cartas y licencia

Arte original de [Basquetteur](https://commons.wikimedia.org/wiki/User:Basquetteur), vectorizado por [gjenkins20](https://github.com/gjenkins20/spanish-playing-cards-svg), bajo [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/). Los SVG fueron convertidos a WebP a 360 × 554 sin modificar las ilustraciones. La atribución también aparece en la aplicación. La licencia de las cartas se conserva y no aplica automáticamente al código del juego.

La arquitectura se apoya en la [documentación oficial de Vite](https://vite.dev/guide/) y las [salas de Socket.IO](https://socket.io/docs/v4/rooms/).
